#!/usr/bin/python3
# -*- coding: utf-8 -*-

def info():
    return None
