#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: İsmail BAŞARAN <ismail.basaran@tubitak.gov.tr> <basaran.ismaill@gmail.com>


class PluginKillSignal(object):

    @property
    def obj_name(self):
        return "KILL_SIGNAL"
